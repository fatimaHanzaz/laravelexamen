<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    public function index()
    {
        // Get all tasks
        $tasks = Task::all();

        // Return view
        return view('index', [ 'tasks' => $tasks ]);
    }

    public function order()
    {
        // Get all tasks order by asc
        $tasks = Task::orderBy('title')->get();

        // Return view
        return view('order', [ 'tasks' => $tasks ]);
    }

    public function showTask($id)
    {
        // Get task by id
        $task = Task::find($id);

        // Return view
    	return view('task', [ 'task' => $task ]);
    }

    public function deleteTask($id)
    {
        // Get task by id
        $task = Task::find($id);

        // delete the task
        $task->delete();

        // Return view
    	return view('delete', [ 'message' => 'The task was successfully deleted.' ]);
    }
}
