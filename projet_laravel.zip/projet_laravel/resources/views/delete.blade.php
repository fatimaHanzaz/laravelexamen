@extends('layouts/layout')

@section('title', 'Task')

@section('main')
	<div class="content">
		<div class="notification is-success is-light">
			{{ $message }}
			<a href="{{ route('home') }}"><strong>return to tasks</strong></a>
		</div>
	</div>
@endsection