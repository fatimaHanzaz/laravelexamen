@extends('layouts/layout')

@section('title', 'Task')

@section('main')
	<div class="task-list">
		<div class="card">
			<div class="card-content">
				<div class="content">
					<h3>{{ $task->title }}</h3>
					<p>{{ $task->description }}</p>
					<div class="">
						<form action="" method="post">
							@csrf
							@method('DELETE')
							<button class="button is-danger">Delete task</button>
						</form>	
					</div>
				</div>
			</div>
			<div class="card-footer">
				<a class="card-footer-item">Date d'ajout : {{$task->created_at->formatLocalized('%A %d %B %Y') }}</a>
			</div>
		</div>
	</div>
@endsection