

<?php $__env->startSection('title', 'Task'); ?>

<?php $__env->startSection('main'); ?>
	<div class="content">
		<div class="notification is-success is-light">
			<?php echo e($message); ?>

			<a href="<?php echo e(route('home')); ?>"><strong>back to tasks</strong></a>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-exam\resources\views/delete.blade.php ENDPATH**/ ?>